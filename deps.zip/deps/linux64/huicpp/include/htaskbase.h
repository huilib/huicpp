/*
 * Created Author: Joseph Hui
 * Created Date: Sun 15 May 2022
 * Description:
 *      Provdes the base of task.
*/


#ifndef __H_HUICPP_TASKBASE_H__
#define __H_HUICPP_TASKBASE_H__

#include "hobjectbase.h"
#include "htime.h"

namespace HUICPP {

class HTaskBase : public HAppObject {
public:
    using base = HAppObject;
    
protected:
    explicit HTaskBase(HCSTRR strName = HSTR("HTaskBase")) noexcept;

    virtual ~HTaskBase() noexcept = default;

public:
    HRET DoWork ();

    const HMicroTime& GetCreateTime() const noexcept { return m_create_time; }

    HLN GetWorkPay() const noexcept { return m_work_pay; }

protected:
    virtual HRET taskWork () = 0;

private:
    HMicroTime m_create_time;
    HLN m_work_pay;
};


class HTaskProducerBase : public HAppObject {
public:
    using base = HAppObject;
protected:
    HTaskProducerBase(HCSTRR strName = HSTR("HTaskProducerBase")) noexcept;

    virtual ~ HTaskProducerBase() noexcept;

public:
    virtual HTaskBase* ProduceTask() = 0;
};


class HTaskConsumerBase : public HAppObject {
public:
    using base = HAppObject;
protected:
    HTaskConsumerBase(HCSTRR strName = HSTR("HTaskConsumerBase")) noexcept;

    virtual ~ HTaskConsumerBase() noexcept;

public:
    virtual HRET Consume(const HTaskBase*) = 0;

};

}


#endif //__H_HUICPP_TASKBASE_H__

