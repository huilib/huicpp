/*
 * Created: Joseph Mar-29-2021
 * Description: 
  		Wrapper for abstract huicpp config base. 
*/


#ifndef __H_HUICPP_INTERNAL_CONFIGBASE_H__
#define __H_HUICPP_INTERNAL_CONFIGBASE_H__

#include "../huicpp.h"

namespace HUICPP {

namespace hc_internal {    

class ConfigBase {
public:
    enum class CONFIG_TYPE {
        CT_BASE,
        CT_NORMAL,
        CT_JSON,
        CT_OTHER
    };

public:
    ConfigBase() { }

    virtual ~ ConfigBase () { }

public:
    virtual CONFIG_TYPE GetType() const noexcept { return CONFIG_TYPE::CT_BASE; }

    HRET ReloadConfig (HCSTRR strConfigFileName);
    
    virtual HRET LoadConfig (HCSTRR strConfigFileName) = 0;

    virtual void Clear() = 0;

public:
    virtual HCSTRR GetValue(HCSTRR strKey) const = 0;

    virtual HCSTRR GetValue(HCSTRR strKey, HCSTRR strDefVal) const noexcept = 0;

    virtual HN GetIntValue(HCSTRR strKey) const = 0;

    virtual HN GetIntValue(HCSTRR strKey, HN nDefVal) const noexcept = 0;

    virtual bool Exists(HCSTRR strKey) const = 0;

    virtual void SetValue (HCSTRR key, HCSTRR val) noexcept = 0;
};

using config_pointer = ConfigBase*;
using const_config_pointer = const ConfigBase*;
using config_map_t = std::map<HSTR, config_pointer>;

}

}


#endif // __H_HUICPP_INTERNAL_CONFIGBASE_H__

