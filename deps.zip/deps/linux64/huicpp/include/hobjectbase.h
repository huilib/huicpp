/*
 * Created Author: Joseph Hui
 * Created Date: Sun 15 May 2022
 * Description:
 *      Provdes some base of objects.
*/


#ifndef __H_HUICPP_OBJECTBASE_H__
#define __H_HUICPP_OBJECTBASE_H__

#include <huicpp.h>

namespace HUICPP {

class HObjectBase {
protected:
    explicit HObjectBase(HCSTRR strName = HSTR("HObjectBase")) noexcept;

    virtual ~HObjectBase() noexcept ;

public:
    HCSTRR GetName () const noexcept { return m_strName; }    

private:
    HCSTR m_strName;    
};

class HApp;
class HAppObject : public HObjectBase {
public:
    using base = HObjectBase;

public:
    explicit HAppObject(HCSTRR strName = HSTR("HAppObject"), HApp* app = nullptr) noexcept;

    virtual ~HAppObject() noexcept ;

public:
    void SetApp(HApp* app) noexcept { m_app = app; }

    HApp* GetApp() noexcept { return m_app; }
    
    const HApp* GetApp () const noexcept { return m_app; }

private:
    HApp* m_app;
};

}


#endif //__H_HUICPP_OBJECTBASE_H__

