

#ifndef __H_SINGLETON_MANAGER_H__
#define __H_SINGLETON_MANAGER_H__

#include "../huicpp.h"

using namespace HUICPP;

namespace HUICPP {

namespace detail {

class SingletonManagerWithRtti {

};


}

}

#endif // __H_SINGLETON_MANAGER_H__

