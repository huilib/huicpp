/*
 * Created: Joseph Hui Sun Sep 26 2021
 * Description: 
  		Wrapper for huicpp file system detail.
*/

#ifndef __H_HUICPP_FILE_SYSTEM_DETAIL_H__
#define __H_HUICPP_FILE_SYSTEM_DETAIL_H__


#include "../huicpp.h"

namespace HUICPP {

namespace detail {

class filesystem_detail {
public:
    typedef HCH path_elem_type;
    typedef HSTR path_str_type;
    typedef HULL filesize_t;
    static constexpr const path_elem_type root_elem = '/';
    static constexpr const path_elem_type po_elem = '.';

protected:
    filesystem_detail() noexcept { }

    explicit filesystem_detail(const path_str_type& strpath) noexcept
        : m_name(strpath) { }

    virtual ~ filesystem_detail() {  }

public:
    const path_str_type& GetName() const noexcept { return m_name; }

    void SetPath (const path_str_type& _path) noexcept { m_name = _path; }

    void Clear() noexcept { m_name.clear(); }

protected:
    bool exists() const noexcept {
        return Exists(m_name);
    }

    bool isDir() const noexcept {
        return IsDir(m_name);
    }

    bool isFile() const noexcept {
        return IsFile(m_name);
    }

    HRET copy (const path_str_type& strPathFileName) const noexcept {
        return Copy(m_name, strPathFileName);
    }

    HRET remove() const noexcept {
        return Remove(m_name);
    }

    HRET fileRename(const path_str_type& strDstPathFileName) noexcept {

        HSTR src_name = m_name;
        HNOTOK_RETURN(Rename(src_name, strDstPathFileName));
        m_name = src_name;
        HRETURN_OK;

    }

    void setAsCurrent() noexcept {
        HIGNORE_RETURN(GetCurrentPath(m_name));
    }

    HRET getParentPath(path_str_type& strParentPath) const noexcept {
        return GetParentPath(m_name, strParentPath);
    }

    HRET createDirectory() const noexcept {
        return CreateDirectory(m_name);
    }

    filesize_t getFileSize() const noexcept {
        return GetFileSize(m_name);
    }

    path_str_type pathJustFileName() const noexcept {
        return PathJustFileName(m_name);
    }

    path_str_type pathOnlyFileName() const noexcept {
        return PathOnlyFileName(m_name);
    }

    path_str_type getFileExternName() const noexcept {
        return GetFileExternName(m_name);
    }

    void setAsAbsolute() noexcept {
        HIGNORE_RETURN(SetAsAbsolute(m_name));
    }

    bool isAbsolute() const noexcept {
        return IsAbsolute(m_name);
    }

    bool isRelative() const noexcept {
        return IsRelative(m_name);
    }

    void append(const path_str_type& new_path) noexcept {
        m_name =  Append(m_name, new_path);
    }

    void getDicSubItems(std::vector<path_str_type>& fns, std::vector<path_str_type>& ds) const {
        GetDicSubItems(m_name, fns, ds);
    }

public:
    static bool Exists(const path_str_type& strPathFileName) noexcept;

    static bool IsDir(const path_str_type& strPathFileName) noexcept;

    static bool IsFile(const path_str_type& strPathFileName) noexcept;

    static HRET Copy(const path_str_type& srcpath, 
        const path_str_type& dstpath) noexcept;

    static HRET Remove(const path_str_type& strPathFileName) noexcept;

    static HRET Rename(const path_str_type& strPathFileName, const path_str_type& strDstPathFileName) noexcept;

    static HRET GetCurrentPath (path_str_type& strPathName) noexcept;

    static HRET GetParentPath (const path_str_type& strCurrentPath,
        path_str_type& strParentPath) noexcept;

    static HRET SetAsAbsolute(path_str_type& strPath) noexcept;

    static HRET CreateDirectory(const path_str_type& strPathFileName) noexcept;

    static filesize_t GetFileSize (const path_str_type& strPathFileName) noexcept;

    static path_str_type PathJustFileName(const path_str_type& strPathFileName) noexcept;

    static path_str_type PathOnlyFileName(const path_str_type& strPathFileName) noexcept;

    static path_str_type GetFileExternName(const path_str_type& strPathFileName) noexcept;

    static bool IsAbsolute(const path_str_type& strPathFileName) noexcept;

    static bool IsRelative(const path_str_type& strPathFileName) noexcept;

    static path_str_type Append(const path_str_type& base_path,
        const path_str_type& new_path) noexcept;

    static bool IsRootBegin(const path_str_type& strPathFileName) noexcept;

    static bool IsRootEnd(const path_str_type& strPathFileName) noexcept;

    static bool IsJustOnlyFileName (const path_str_type& strPathFileName);

    static void GetDicSubItems(const path_str_type& dicname, std::vector<path_str_type>& fns, std::vector<path_str_type>& ds);

private:
    bool is_root_begin() const noexcept {
        return IsRootBegin(m_name);
    }

    bool is_root_end() const noexcept {
        return IsRootEnd(m_name);
    }
    
private:
    path_str_type m_name;
};


}

}

#endif // __H_HUICPP_FILE_SYSTEM_DETAIL_H__